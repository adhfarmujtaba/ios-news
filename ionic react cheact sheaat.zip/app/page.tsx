"use client"
import { useState, useEffect, useRef } from "react"
import SearchBar from "@/components/search-bar"
import CategoryFilter from "@/components/category-filter"
import NewsGrid from "@/components/news-grid"
import TrendingNews from "@/components/trending-news"
import FollowingNews from "@/components/following-news"

// Weather Widget Component
const WeatherWidget = () => {
  return (
    <div className="bg-gray-100 rounded-lg p-4 mb-4 flex items-center justify-between">
      <div>
        <h2 className="text-xl font-bold">San Francisco</h2>
        <p className="text-gray-600">Cloudy</p>
      </div>
      <div className="text-3xl font-bold">
        64°
      </div>
    </div>
  )
}

// Tab Navigation Component
const TabNavigation = ({ activeTab, onTabChange }) => {
  const tabs = [
    { id: "forYou", label: "For You" },
    { id: "following", label: "Following" },
    { id: "trending", label: "Trending" }
  ]

  return (
    <div className="flex border-b border-gray-200">
      {tabs.map((tab) => (
        <button
          key={tab.id}
          className={`flex-1 py-3 text-center ${
            activeTab === tab.id 
              ? "font-bold border-b-2 border-blue-500 text-blue-500" 
              : "text-gray-500"
          }`}
          onClick={() => onTabChange(tab.id)}
        >
          {tab.label}
        </button>
      ))}
    </div>
  )
}

export default function Home() {
  const [activeTab, setActiveTab] = useState("forYou")
  const [isScrolled, setIsScrolled] = useState(false)
  const mainContainerRef = useRef(null)

  useEffect(() => {
    const handleScroll = () => {
      if (mainContainerRef.current) {
        setIsScrolled(mainContainerRef.current.scrollTop > 10)
      }
    }

    const container = mainContainerRef.current
    if (container) {
      container.addEventListener("scroll", handleScroll)
    }

    return () => {
      if (container) {
        container.removeEventListener("scroll", handleScroll)
      }
    }
  }, [])

  const renderContent = () => {
    switch(activeTab) {
      case "forYou":
        return (
          <div className="px-4">
            <WeatherWidget />
            <div className="mb-4 bg-gray-100 rounded-lg p-3">
              <span className="text-blue-600 font-semibold">Recommended</span>
              <h3 className="text-sm mt-1">The Future of Web Development: AI-Assisted Coding</h3>
              <p className="text-xs text-gray-500">Tech Insights • Mar 10, 2025</p>
            </div>
            <SearchBar className="mb-4" redirectToHome={true} />
            <CategoryFilter className="mb-6" />
            <NewsGrid />
          </div>
        )
      case "following":
        return (
          <div className="px-4">
            <FollowingNews />
          </div>
        )
      case "trending":
        return (
          <div className="px-4">
            <TrendingNews />
          </div>
        )
      default:
        return null
    }
  }

  return (
    <div className="ios-app-container">
      <main ref={mainContainerRef} className="ios-main-container pb-20 overflow-y-auto">
        <TabNavigation 
          activeTab={activeTab} 
          onTabChange={setActiveTab} 
        />
        
        <div className={`ios-header ${isScrolled ? "scrolled" : ""}`}>
          <h1 className="ios-header-title">
            {activeTab === "forYou" && "For You"}
            {activeTab === "following" && "Following"}
            {activeTab === "trending" && "Trending"}
          </h1>
        </div>

        {renderContent()}
      </main>
    </div>
  )
}