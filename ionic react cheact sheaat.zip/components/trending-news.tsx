"use client"

import { useContext } from "react"
import { Flame } from "lucide-react"
import NewsCard from "@/components/news-card"
import { NewsContext } from "@/context/news-context"
import { SettingsContext } from "@/context/settings-context"

export default function TrendingNews() {
  const { trendingNews = [] } = useContext(NewsContext) || {}
  const { settings } = useContext(SettingsContext) || {}

  if (!trendingNews || trendingNews.length === 0) {
    return (
      <div className="ios-empty-state">
        <Flame className="ios-empty-icon" />
        <h3 className="ios-empty-title">No trending news</h3>
        <p className="ios-empty-description">Check back later for hot stories.</p>
      </div>
    )
  }

  return (
    <div className={settings?.defaultView === "grid" ? "ios-grid-layout" : "ios-list-layout"}>
      {trendingNews.map((news) => (
        <NewsCard key={news.slug} news={news} view={settings?.defaultView} />
      ))}
    </div>
  )
}