"use client"

import { useContext } from "react"
import { UsersRound } from "lucide-react"
import NewsCard from "@/components/news-card"
import { NewsContext } from "@/context/news-context"
import { SettingsContext } from "@/context/settings-context"

export default function FollowingNews() {
  const { followedNews = [] } = useContext(NewsContext) || {}
  const { settings } = useContext(SettingsContext) || {}

  if (!followedNews || followedNews.length === 0) {
    return (
      <div className="ios-empty-state">
        <UsersRound className="ios-empty-icon" />
        <h3 className="ios-empty-title">No followed news</h3>
        <p className="ios-empty-description">Follow sources to see their latest stories.</p>
      </div>
    )
  }

  return (
    <div className={settings?.defaultView === "grid" ? "ios-grid-layout" : "ios-list-layout"}>
      {followedNews.map((news) => (
        <NewsCard key={news.slug} news={news} view={settings?.defaultView} />
      ))}
    </div>
  )
}